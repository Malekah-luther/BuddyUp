package com.codebeginner.sovary.fingerprinttest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.concurrent.Executor;
import static androidx.biometric.BiometricManager.Authenticators.*;

public class MainActivity extends AppCompatActivity {

    Button btn_fp, btn_fppin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Assign button reference from view
        btn_fp = findViewById(R.id.btn_fp);
        btn_fppin = findViewById(R.id.btn_fppin);

        // Create new method to check whether support or not
        checkBioMetricSupported();
    }

    private void checkBioMetricSupported() {
        BiometricManager biometricManager = BiometricManager.from(this);
        switch (biometricManager.canAuthenticate(BIOMETRIC_STRONG | DEVICE_CREDENTIAL)) {
            case BiometricManager.BIOMETRIC_SUCCESS:
                Log.d("MY_APP_TAG", "App can authenticate using biometrics.");
                break;
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                Toast.makeText(this, "No biometric features available on this device.", Toast.LENGTH_SHORT).show();
                break;
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                Toast.makeText(this, "Biometric features are currently unavailable.", Toast.LENGTH_SHORT).show();
                break;
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                // Prompts the user to create credentials that your app accepts.
                final Intent enrollIntent = new Intent(Settings.ACTION_BIOMETRIC_ENROLL);
                enrollIntent.putExtra(Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED, BIOMETRIC_STRONG | DEVICE_CREDENTIAL);
                startActivityForResult(enrollIntent, 1001);
                break;
        }
    }
}
//must running android 6
void checkBioMetricSupported()
{
    BiometricManager manager = BiometricManager.from(this);
    String info="";
    switch (manager.canAuthenticate(BIOMETRIC_WEAK | BIOMETRIC_STRONG))
    {
        case BiometricManager.BIOMETRIC_SUCCESS:
            info = "App can authenticate using biometrics.";
            enableButton(true);
            break;
        case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
            info = "No biometric features available on this device.";
            enableButton(false);
            break;
        case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
            info = "Biometric features are currently unavailable.";
            enableButton(false);
            break;
        case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
            info = "Need register at least one finger print";
            enableButton(false,true);
            break;
        default:
            info= "Unknown cause";
            enableButton(false);
    }

    //set message to text view so we can see what happen with sensor device
    TextView txinfo =  findViewById(R.id.tx_info);
    txinfo.setText(info);
}

