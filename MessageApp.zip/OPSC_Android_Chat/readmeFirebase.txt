1] connect to firebase (cloud firestore)
2] connect the app properly using SH1 certificate (if you dont know how message me)
3] update the google-services.json file
( 3 steps above like 7 mins max)

4] browse through the following videos and replicate whatever the guy did for firebase but since the code is there itll just be
to change it (copy paste in certain places).

5, 6 7 8 13 14 15 16 19 20